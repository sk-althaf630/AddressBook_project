/*
Name: Shaik.Althaf
Project: MP3 Tag Editor 
Submission Date: 25/02/2026
Description:--
This project implements an MP3 Tag Editor using the C programming language. MP3 files often contain ID3 
metadata tags, which store information such as the song title, artist, album, year, genre, and comments. 
Managing these tags is essential for organizing digital music libraries and ensuring compatibility across 
different media players.
The system provides functionality to read, edit, and update ID3v2 metadata within MP3 files. It allows users 
to modify fields like track name, artist, album, and custom comments, while preserving the audio stream intact.
 */


#include <stdio.h>
#include <string.h>
#include "file.h"
#include "types.h"

/* Decide which operation user requested */
operatorType check_valid_command(char *argv[])
{
    if(strcmp(argv[1], "-v") == 0)
    {
        return e_viewoption;
    }
    else if(strcmp(argv[1], "-e") == 0)
    {
        return e_editoption;
    }
    else if(strcmp(argv[1], "--help") == 0)
    {
        return e_helpoption;
    }
    else
    {
        return e_invalidoption;
    }
}

void MP3_help()
{
    printf("\n--- MP3 Tag  Editor Help ---\n");
    printf("Uage: ./a.out [flag] [sorce_filename] [tage_name] [new_text] [temp_filename]\n");
    printf("Flages: \n");
    printf("    -v : View metadata\n");
    printf("    -e : Edit Title(TIT2)\n");
    printf("    --help : Displar this menu\n");
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        MP3_help();
        return e_failure;
    }
    mp3Info stu_Info;
    operatorType choices = check_valid_command(argv);

    switch (choices)
    {
    case e_viewoption:
        if (argc < 3 || read_validate_view_args(argv, &stu_Info) == e_failure)
        {
            printf("Error: Usage for view : ./a.out -v [file_name].\n");
        }
        else
        {
            MP3_view(&stu_Info);
        }
        break;

    case e_editoption:
        if (argc < 4 || read_validate_edit_args(argv, &stu_Info) == e_failure)
        {
            printf("Error: Usage for edit : ./a.out -e [file_name]  [tage_name] [new_text] \"[temp_filename]\"\n");
        }
        else
        {
           MP3_edit(&stu_Info);
        }
        break;

    case e_helpoption: // Handles --help
        MP3_help();
        break;

    default:
        printf("Unknown flag: %s\n", argv[1]);
        MP3_help();
        break;
    }

    return 0;
}