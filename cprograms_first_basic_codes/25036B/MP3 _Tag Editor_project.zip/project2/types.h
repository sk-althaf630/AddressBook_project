#ifndef TYPES_H
#define TYPES_H

typedef unsigned int uint;
typedef unsigned char uchar;

/*status will be used in function return type*/
typedef enum
{
    e_failure,
    e_success
}status;

/*Operator types for command-line flags*/
typedef enum
{
    e_viewoption,
    e_editoption,
    e_helpoption,
    e_invalidoption
}operatorType;
#endif