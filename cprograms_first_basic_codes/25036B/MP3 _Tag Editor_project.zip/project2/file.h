#ifndef FILE_H
#define FILE_H

#include <stdio.h>
#include "types.h"

#define MAX_FRAME_ID_SIZE 5
#define MAX_TAGE_SIZE 4



typedef struct _mp3Info
{
    /* source mp3 Info */
    char *src_mp3_fname;
    FILE *fptr_src_mp3;
    uchar frame_id[MAX_FRAME_ID_SIZE];//tage stroge perpase
    uchar size_tage[MAX_TAGE_SIZE];//tage size stroge perpase
    

    /* temp mp3 Info for editing */
    char *temp_mp3_fname;
    FILE *fptr_temp_mp3;
    char *new_text;
    char tage_name[MAX_TAGE_SIZE];

}mp3Info;

/* validtions logics */
operatorType check_valid_command(char *argv[]);
status read_validate_view_args(char *argv[], mp3Info *mp3info);
status read_validate_edit_args(char *argv[], mp3Info *mp3info);


/*Bit helpers */
void int_to_syncsafe(int size, uchar bytes[4]);
int syncsafe_to_int(const uchar bytes[4]);


/* Logic functions */
void MP3_view(mp3Info *mp3info);
void MP3_edit(mp3Info *mp3info);
void MP3_help();

#endif