#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "file.h"
#include "types.h"

// Convert an integer size into a 4-byte syncsafe format..
void int_to_syncsafe(int size, unsigned char bytes[4])
{
    bytes[0] = (size >> 21) & 0x7F;
    bytes[1] = (size >> 14) & 0x7F;
    bytes[2] = (size >> 7) & 0x7F;
    bytes[3] = size & 0x7F;
}

// Validate arguments for editing MP3 tags..
status read_validate_edit_args(char *argv[], mp3Info *mp3info)
{
    // First validate using view_args (basic checks)
    if (read_validate_view_args(argv, mp3info) == e_failure)
    {
      return e_failure;
    }
    
    // Check if tag name is provided and exactly 4 characters
    if(argv[3] == NULL || strlen(argv[3]) != 4 )
    {
      return e_failure;
    }
    else
    {
      // Allowed tags list (ID3v2 frames)
      const char *valid_tage[] ={"TIT2", "TPE1", "TALB", "TYER", "TCON", "COMM"};
      int flage = 0;

      // Compare user-provided tag with allowed tags
      for(int i = 0; i < 6; i++)
      {
        if(strcmp(argv[3], valid_tage[i]) == 0)
        {
          flage = 1;
          strcpy( mp3info->tage_name,argv[3]);
        }
      }
      if(flage == 0)
      {
        printf("ERROR : YOU passed tage is worring plz correct it\n");
        return e_failure;

      }

   }
  


    // Validate new text (the replacement string)
    mp3info->new_text = argv[4];
    if( mp3info->new_text == NULL)
    {
      return e_failure;
    }

    if(argv[5] != NULL)
    {
      char *ext = strstr(argv[5], ".");
      if(ext && strcmp(ext, ".mp3") == 0)
      {
        // Prevent overwriting the source file..
        if(strcmp(mp3info->src_mp3_fname, argv[5]) == 0)
        {
          printf("ERROR : Both files are same change any one file..\n");
          return e_failure;
        }
        mp3info-> temp_mp3_fname = argv[5];
      }
      else
      {
        return e_failure;
      }
    }
    else
    {
      mp3info-> temp_mp3_fname = "temp_out.mp3";
    }

    return e_success;
}

// Function to edit MP3 metadata..
void MP3_edit(mp3Info *mp3info)
{
    mp3info->fptr_src_mp3 = fopen(mp3info->src_mp3_fname, "rb");
    if (!mp3info->fptr_src_mp3)
    {
        perror("fopen");
        return;
    }

    mp3info->fptr_temp_mp3 = fopen(mp3info->temp_mp3_fname, "wb");
    if (!mp3info->fptr_temp_mp3)
    {
        perror("fopen");
        fclose(mp3info->fptr_src_mp3);
        return;
    }

    // Copy the 10-byte ID3 header
    unsigned char header[10];
    fread(header, 1, 10, mp3info->fptr_src_mp3);
    fwrite(header, 1, 10, mp3info->fptr_temp_mp3);

    // Loop through frames in the MP3 file
    while (fread(mp3info->frame_id, 1, 4, mp3info->fptr_src_mp3) == 4)
    {
        mp3info->frame_id[4] = '\0';

        // Read frame size (syncsafe format)
        if (fread(mp3info->size_tage, 1, 4, mp3info->fptr_src_mp3) != 4)
        {
            break;
        }

        int size = syncsafe_to_int(mp3info->size_tage);

        // Read frame flags
        unsigned char flags[2];
        fread(flags, 1, 2, mp3info->fptr_src_mp3);

        // If this is the tag we want to edit
        if (strcmp(mp3info->frame_id, mp3info->tage_name) == 0)
        {
            int new_size = strlen(mp3info->new_text) + 1;// +1 for encoding byte
            unsigned char new_size_bytes[4];
            int_to_syncsafe(new_size, new_size_bytes);

            // Write updated frame header
            fwrite(mp3info->frame_id, 1, 4, mp3info->fptr_temp_mp3);
            fwrite(new_size_bytes, 1, 4, mp3info->fptr_temp_mp3);
            fwrite(flags, 1, 2, mp3info->fptr_temp_mp3);

            // Write encoding byte (0 = ISO-8859-1)
            unsigned char encoding = 0;
            fwrite(&encoding, 1, 1, mp3info->fptr_temp_mp3);
            fwrite(mp3info->new_text, 1, strlen(mp3info->new_text), mp3info->fptr_temp_mp3);

            // Write new text
            fseek(mp3info->fptr_src_mp3, size, SEEK_CUR);
        }
        else
        {
            // Copy frame unchanged
            fwrite(mp3info->frame_id, 1, 4, mp3info->fptr_temp_mp3);
            fwrite(mp3info->size_tage, 1, 4, mp3info->fptr_temp_mp3);
            fwrite(flags, 1, 2, mp3info->fptr_temp_mp3);

            char *buffer = malloc(size);
            if(buffer == NULL)
            {
              perror("malloc");
              return;
            }

            fread(buffer, 1, size, mp3info->fptr_src_mp3);
            fwrite(buffer, 1, size, mp3info->fptr_temp_mp3);
            free(buffer);
        }
    }

    // Copy remaining audio data (after metadata frames)
    char buf[1024];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), mp3info->fptr_src_mp3)) > 0)
    {
        fwrite(buf, 1, n, mp3info->fptr_temp_mp3);
    }

    // Close files
    fclose(mp3info->fptr_src_mp3);
    fclose(mp3info->fptr_temp_mp3);

    printf("Edit complete. New file saved as %s\n", mp3info->temp_mp3_fname);

}