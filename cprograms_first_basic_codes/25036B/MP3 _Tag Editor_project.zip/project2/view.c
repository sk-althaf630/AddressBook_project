#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "file.h"
#include "types.h"

//convert sync-safe back to integer
int syncsafe_to_int(const uchar bytes[4])
{
    return ((bytes[0] & 0x7F) << 21) |
           ((bytes[1] & 0x7F) << 14) |
           ((bytes[2] & 0x7F) << 7)  |
           (bytes[3] & 0x7F);
}
status read_validate_view_args(char *argv[], mp3Info *mp3info)
{
    //assigning file name to structure and checking file is .mp3 extan
    mp3info->src_mp3_fname = argv[2];
    if(strstr(mp3info->src_mp3_fname, ".mp3") == NULL)
    {
        return e_failure;
    }

    return e_success;
}

void MP3_view(mp3Info *mp3info)
{
    //assign to file pointer
    mp3info->fptr_src_mp3 = fopen(mp3info->src_mp3_fname, "rb");

    if(!mp3info->fptr_src_mp3)
    {
        perror("fopen");
        fprintf(stderr,"ERROR : Unable to open files %s\n", mp3info->src_mp3_fname);
        return;
    }

    //skip 10-bytes of ID3 Header
    fseek(mp3info->fptr_src_mp3,10,SEEK_SET);

    int count = 0;
    while(count < 6)
    {
        if(fread(mp3info->frame_id, 1,4,mp3info->fptr_src_mp3) != 4)
        {
            break;
        }
        mp3info->frame_id[4] = '\0';

        if((fread(mp3info->size_tage, 1, 4, mp3info->fptr_src_mp3)) != 4)//check  the fread is reading successfully or not
        {
            printf("Error or end of file.\n");
            return;
        }
        int size = syncsafe_to_int(mp3info->size_tage);
        fseek(mp3info->fptr_src_mp3, 3, SEEK_CUR);//skip for flage

        
        char *Buffer = malloc(size);//Buffer to store the frame text
        if(!Buffer)
        {
            break;
        }
        if((fread(Buffer, 1, size-1,mp3info->fptr_src_mp3)) != (size - 1))//check the fread is reading successfully or not
        {
            printf("Error or end of file.\n");
            free(Buffer);
            return;
        }
        Buffer[size-1] = '\0';
        if(strcmp(mp3info->frame_id, "TIT2") == 0 || strcmp(mp3info->frame_id, "TPE1") == 0 || strcmp(mp3info->frame_id, "TALB") == 0 ||
           strcmp(mp3info->frame_id, "TYER") == 0 || strcmp(mp3info->frame_id, "TCON") == 0 || strcmp(mp3info->frame_id, "COMM") == 0)
        {
            printf("%s : %s\n", mp3info->frame_id, Buffer);
            count++;
        }
        free(Buffer);
    }
    fclose(mp3info->fptr_src_mp3);
}